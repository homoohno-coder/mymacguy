/* mymacguy.net — site JS */
(function () {
  "use strict";

  /* mobile nav */
  const toggle = document.querySelector(".nav-toggle");
  const links = document.querySelector(".nav-links");
  if (toggle && links) {
    toggle.addEventListener("click", () => links.classList.toggle("open"));
  }

  /* mark active nav link */
  const path = window.location.pathname.replace(/\/index\.html$/, "/").replace(/\.html$/, "");
  document.querySelectorAll(".nav-links a[data-href]").forEach((a) => {
    const href = a.getAttribute("data-href");
    if (href === path || (href === "/" && (path === "/" || path === ""))) {
      a.classList.add("active");
    }
  });

  /* scroll reveal */
  const io = new IntersectionObserver(
    (entries) => {
      entries.forEach((e) => {
        if (e.isIntersecting) {
          e.target.classList.add("in");
          io.unobserve(e.target);
        }
      });
    },
    { threshold: 0.12, rootMargin: "0px 0px -8% 0px" }
  );
  document.querySelectorAll(".reveal").forEach((el) => io.observe(el));

  /* hero word swap */
  const swap = document.querySelector(".swap");
  if (swap) {
    const words = JSON.parse(swap.dataset.words || "[]");
    if (words.length > 1) {
      let i = 0;
      setInterval(() => {
        i = (i + 1) % words.length;
        swap.style.opacity = "0";
        setTimeout(() => {
          swap.textContent = words[i];
          swap.style.opacity = "1";
        }, 220);
      }, 2800);
      swap.style.transition = "opacity .25s";
    }
  }

  /* year */
  document.querySelectorAll("[data-year]").forEach((el) => {
    el.textContent = new Date().getFullYear();
  });

  /* Zoho Assist session join.
     Customer-side join URL pattern: https://assist.zoho.com/join.html?key=XXXXXX
     Wahed sends a 6-digit code; visitor types it; we open the session in a new tab. */
  const form = document.getElementById("zoho-form");
  if (form) {
    const input = document.getElementById("zoho-key");
    const status = document.getElementById("zoho-status");

    const sanitize = (v) => v.replace(/[^A-Za-z0-9]/g, "").slice(0, 10);

    input.addEventListener("input", (e) => {
      e.target.value = sanitize(e.target.value);
    });

    form.addEventListener("submit", (e) => {
      e.preventDefault();
      const key = sanitize(input.value);
      status.className = "portal-status show";
      if (key.length < 6) {
        status.classList.add("error");
        status.textContent = "Enter the 6–10 character session code Wahed gave you.";
        return;
      }
      status.classList.remove("error");
      status.textContent = "Opening secure Zoho Assist session in a new tab…";
      const url = "https://join.zoho.com/?key=" + encodeURIComponent(key);
      window.open(url, "_blank", "noopener");
    });
  }

  /* request session — phone/sms quick action */
  const req = document.getElementById("request-session");
  if (req) {
    req.addEventListener("click", () => {
      const msg = encodeURIComponent("Hi Wahed — please send me a Zoho Assist session code.");
      window.location.href = "sms:+13109801964?body=" + msg;
    });
  }
})();
